document.getElementsByTagName("h1")[0].style.fontSize = "6vw"
async function translateText() {
    const text = document.getElementById('inputText').value;
    const targetLanguage = document.getElementById('languageSelect').value;

    if (!text) {
        alert("Please enter text to translate.");
        return;
    }

    const url = 'https://libretranslate.de/translate';

    const data = {
        q: text,
        target: targetLanguage,
        source: 'en'  // Assuming input text is in English
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();

        // Display the translated text
        const translatedText = result.translatedText;
        document.getElementById('translatedText').innerText = translatedText;
    } catch (error) {
        console.error("Error during translation:", error);
        alert("There was an error with the translation. Please try again.");
    }
}const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();

function startVoiceInput() {
    recognition.start();

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        document.getElementById('inputText').value = transcript;
    };
}function speakTranslation() {
    const translatedText = document.getElementById('translatedText').innerText;
    const utterance = new SpeechSynthesisUtterance(translatedText);
    utterance.lang = document.getElementById('languageSelect').value; // Set language
    speechSynthesis.speak(utterance);
}
function saveTranslation() {
    const translatedText = document.getElementById('translatedText').innerText;
    let history = JSON.parse(localStorage.getItem('translationHistory')) || [];
    history.push(translatedText);
    localStorage.setItem('translationHistory', JSON.stringify(history));
}
function toggleTheme() {
    document.body.classList.toggle('dark-mode');
}
function adjustFontSize() {
    const fontSize = document.getElementById('fontSize').value;
    document.getElementById('translatedText').style.fontSize = fontSize + 'px';
}
function speakTranslation() {
    const translatedText = document.getElementById('translatedText').innerText;
    const utterance = new SpeechSynthesisUtterance(translatedText);
    utterance.lang = document.getElementById('languageSelect').value;
    speechSynthesis.speak(utterance);
}

function saveTranslation() {
    const translatedText = document.getElementById('translatedText').innerText;
    let history = JSON.parse(localStorage.getItem('translationHistory')) || [];
    history.push(translatedText);
    localStorage.setItem('translationHistory', JSON.stringify(history));
}

function toggleTheme() {
    document.body.classList.toggle('dark-mode');
}
function botTyping(message) {
    const botMessage = document.createElement('div');
    botMessage.classList.add('bot');
    const avatar = document.createElement('div');
    avatar.classList.add('bot-avatar');
    botMessage.appendChild(avatar);
    botMessage.appendChild(document.createTextNode("...typing"));

    document.getElementById('messages').appendChild(botMessage);
    document.getElementById('chatbox').scrollTop = document.getElementById('chatbox').scrollHeight; 

    setTimeout(() => {
        botMessage.textContent = message;
        botMessage.classList.remove("bot-avatar");
    }, 1500);
}
async function detectLanguage(text) {
    const response = await fetch(`https://libretranslate.de/detect`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ q: text })
    });
    const result = await response.json();
    return result[0].language;
}
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();

function startVoiceInput() {
    recognition.start();

    recognition.onresult = function(event) {
        const transcript = event.results[0][0].transcript;
        document.getElementById('inputText').value = transcript;
    };
}
function speakTranslation() {
    const translatedText = document.getElementById('translatedText').innerText;
    const utterance = new SpeechSynthesisUtterance(translatedText);
    utterance.lang = 'en';  // Set language
    speechSynthesis.speak(utterance);
}
function botReplyWithFollowUp() {
    setTimeout(() => {
        displayMessage("Is there another language you'd like me to translate to?", 'bot');
    }, 1500);
}
function handleImageUpload() {
    const file = document.getElementById('imageInput').files[0];
    if (file) {
        Tesseract.recognize(
            file,
            'eng', // You can change the language here
            {
                logger: (m) => console.log(m) // Optional, for logging progress
            }
        ).then(({ data: { text } }) => {
            console.log(text);  // Extracted text
            document.getElementById('inputText').value = text; // Display extracted text in input
            enableTranslateButton();
        });
    }
}
function displayTranslation(translatedText, targetLanguage) {
    const flag = document.getElementById('languageFlag');
    if (targetLanguage === 'fr') {
        flag.src = 'https://www.countryflags.io/fr/flat/32.png'; // French Flag URL
    } else if (targetLanguage === 'es') {
        flag.src = 'https://www.countryflags.io/es/flat/32.png'; // Spanish Flag URL
    }
    document.getElementById('translatedText').innerText = translatedText;
}
// Speech Recognition setup
const recognition = new (window.SpeechRecognition || window.webkitSpeechRecognition)();
recognition.lang = 'en-US'; // Set the language for speech recognition (e.g., 'en-US', 'es-ES')

document.getElementById('startSpeechBtn').onclick = () => {
    recognition.start(); // Start listening
};

// Listen for speech input
recognition.onresult = (event) => {
    const speechToText = event.results[0][0].transcript;
    document.getElementById('speechResult').innerText = "You said: " + speechToText;

    // Now, you can pass this text to your translation function
    translateText(speechToText);
};

recognition.onerror = (event) => {
    console.error("Speech recognition error", event);
};
async function translateText(inputText) {
    const targetLanguage = document.getElementById('languageSelect').value; // Get the target language from the dropdown

    const url = 'https://libretranslate.de/translate';
    const data = {
        q: inputText,
        target: targetLanguage,
        source: 'en' // Default source language is English
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        const translatedText = result.translatedText;

        // Display translated text in the chat
        displayMessage(translatedText, 'bot');
    } catch (error) {
        console.error('Error translating text:', error);
        displayMessage("Sorry, there was an error with the translation.", 'bot');
    }
}
function speakTranslatedText(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US'; // Set language for speech synthesis (adjust based on target language)
    speechSynthesis.speak(utterance);
}
// After getting translatedText
speakTranslatedText(translatedText);
function toggleTheme() {
    const body = document.body;
    body.classList.toggle("dark-theme");
}
function speakError(message) {
    const utterance = new SpeechSynthesisUtterance(message);
    utterance.lang = 'en-US';
    speechSynthesis.speak(utterance);
}



